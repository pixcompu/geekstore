<div id="header">
    <div id="brand">
        <a href="principal.php"><img src="../resources/images/tab/tab_icon.png" alt=""></a>
        <p>GeekStore</p>
    </div>
    <div id="session">
        <ul id="session-options">
            <li><a class="login-item" href="register.php">Reg&iacute;strate</a></li>
            <li><a class="login-item" href="login.php">Inicia Sesi&oacute;n</a></li>
        </ul>
    </div>
    <div id="navbar">
        <ul id="navbar-options">
            <li><a class="navbar-item" href="catalog.php">Productos</a></li>
            <li><a class="navbar-item" href="cart.php">Mi Carrito</a></li>
            <li><a class="navbar-item" href="contact.php">Contacto</a></li>
        </ul>
    </div>
</div>