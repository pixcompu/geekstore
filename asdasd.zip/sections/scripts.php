<script src="../javascript/notifier.js"></script>
<script src="../javascript/navbar.js"></script>