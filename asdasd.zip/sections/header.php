<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="../resources/images/tab/tab_icon.png">
<title> <?= isset($sectionTitle)?$sectionTitle:'Geekstore' ?> </title>
<link rel="stylesheet" href="../style/header.css">
<link rel="stylesheet" href="../style/home.css">
<link rel="stylesheet" href="../style/notifier.css">
<script src="../javascript/ajax.js"></script>
<script src="../javascript/cookies.js"></script>
<script src="../javascript/factory.js"></script>