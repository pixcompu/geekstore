<?php
/**
 * Path Information
 */
define('PROJECT_FOLDER_NAME', 'store');
define('BASE_SERVER_PATH', '../../');
define('BASE_SERVER_CLASS_PÁTH', BASE_SERVER_PATH . 'class/');
define('BASE_SERVER_LIBRARY_PATH', BASE_SERVER_PATH . 'lib/');

/**
 * Session Information
 */
define('TYPE_ADMIN', "admin");
define('TYPE_USER', "user");

/**
 * Database Information
 */
/*
define('DIRECCION', 'mysql.hostinger.mx');
define('USER', 'u791421986_pix');
define('PASSWORD', 'naruto1993');
define('DATABASE', 'u791421986_geek');
*/
/*
define('DIRECCION', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DATABASE', 'geekstore');
*/