<?php
require_once($_SERVER['DOCUMENT_ROOT'] . '/geekstore/server/autoloader.php');