# GeekStore.

Proyecto final de Programación WEB.

Geeekstore es una pagina que simula ser una tienda en linea de articulos de peliculas/anime/series.

##Sitio de prueba en linea.
######Proveedor de Hosting : Hostinger
######Ultima Actualización : 06/05/2016.

http://pixcompu.esy.es/sections/principal.php

## Capturas

####Pantalla de Carga

![loading](https://cloud.githubusercontent.com/assets/11744752/14947216/45669540-0ff5-11e6-9f64-c59db1fafd3a.png)

####Vista de Visitante

![no_loggued](https://cloud.githubusercontent.com/assets/11744752/14947215/4565269c-0ff5-11e6-807d-f039858d996f.png)

#### Vista de Administrador

![loggued](https://cloud.githubusercontent.com/assets/11744752/14947217/4568be2e-0ff5-11e6-9b6d-88ed7cc29fd0.png)
